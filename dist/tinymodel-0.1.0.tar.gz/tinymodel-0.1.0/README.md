# TinyModel

TinyModel is a lightweight Python package for AI model completions.

## Installation

Install TinyModel using pip:

```bash
pip install tinymodel
